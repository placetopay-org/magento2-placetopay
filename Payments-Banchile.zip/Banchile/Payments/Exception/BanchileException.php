<?php

namespace Banchile\Payments\Exception;

use Exception;

/**
 * Class BanchileException.
 */
class BanchileException extends Exception
{
}
