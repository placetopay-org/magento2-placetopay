<?php

namespace Banchile\Payments\Logger;

use Monolog\Logger as CustomLogger;

/**
 * Class Logger.
 */
class Logger extends CustomLogger
{
}
